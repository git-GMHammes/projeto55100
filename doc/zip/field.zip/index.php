<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erro 403 - Acesso Negado</title>
</head>
<body>
    <h1>Erro 403 - Acesso Negado</h1>
    <p>Você não tem permissão para acessar esta página.</p>
</body>
</html>